﻿
namespace CTI_Utilities
{
    partial class CTI_Utilties : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public CTI_Utilties()
            : base(Globals.Factory.GetRibbonFactory())
        {
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl1 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl2 = this.Factory.CreateRibbonDropDownItem();
            this.tab1 = this.Factory.CreateRibbonTab();
            this.group2 = this.Factory.CreateRibbonGroup();
            this.editBox2 = this.Factory.CreateRibbonEditBox();
            this.editBox3 = this.Factory.CreateRibbonEditBox();
            this.editBox4 = this.Factory.CreateRibbonEditBox();
            this.group3 = this.Factory.CreateRibbonGroup();
            this.button9 = this.Factory.CreateRibbonButton();
            this.group1 = this.Factory.CreateRibbonGroup();
            this.label1 = this.Factory.CreateRibbonLabel();
            this.editBox1 = this.Factory.CreateRibbonEditBox();
            this.buttonGroup1 = this.Factory.CreateRibbonButtonGroup();
            this.button5 = this.Factory.CreateRibbonButton();
            this.button1 = this.Factory.CreateRibbonButton();
            this.separator1 = this.Factory.CreateRibbonSeparator();
            this.label2 = this.Factory.CreateRibbonLabel();
            this.editBox5 = this.Factory.CreateRibbonEditBox();
            this.box1 = this.Factory.CreateRibbonBox();
            this.button6 = this.Factory.CreateRibbonButton();
            this.button2 = this.Factory.CreateRibbonButton();
            this.checkBox1 = this.Factory.CreateRibbonCheckBox();
            this.separator2 = this.Factory.CreateRibbonSeparator();
            this.label3 = this.Factory.CreateRibbonLabel();
            this.editBox6 = this.Factory.CreateRibbonEditBox();
            this.buttonGroup2 = this.Factory.CreateRibbonButtonGroup();
            this.button7 = this.Factory.CreateRibbonButton();
            this.button3 = this.Factory.CreateRibbonButton();
            this.separator3 = this.Factory.CreateRibbonSeparator();
            this.label4 = this.Factory.CreateRibbonLabel();
            this.editBox7 = this.Factory.CreateRibbonEditBox();
            this.buttonGroup3 = this.Factory.CreateRibbonButtonGroup();
            this.button8 = this.Factory.CreateRibbonButton();
            this.button4 = this.Factory.CreateRibbonButton();
            this.group4 = this.Factory.CreateRibbonGroup();
            this.button10 = this.Factory.CreateRibbonButton();
            this.dropDown1 = this.Factory.CreateRibbonDropDown();
            this.tab1.SuspendLayout();
            this.group2.SuspendLayout();
            this.group3.SuspendLayout();
            this.group1.SuspendLayout();
            this.buttonGroup1.SuspendLayout();
            this.box1.SuspendLayout();
            this.buttonGroup2.SuspendLayout();
            this.buttonGroup3.SuspendLayout();
            this.group4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab1
            // 
            this.tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office;
            this.tab1.Groups.Add(this.group2);
            this.tab1.Groups.Add(this.group3);
            this.tab1.Groups.Add(this.group1);
            this.tab1.Groups.Add(this.group4);
            this.tab1.Label = "CTI Utilities";
            this.tab1.Name = "tab1";
            // 
            // group2
            // 
            this.group2.Items.Add(this.editBox2);
            this.group2.Items.Add(this.editBox3);
            this.group2.Items.Add(this.editBox4);
            this.group2.Label = "Document Info";
            this.group2.Name = "group2";
            // 
            // editBox2
            // 
            this.editBox2.Label = "Account";
            this.editBox2.Name = "editBox2";
            this.editBox2.Text = null;
            this.editBox2.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.EditBox2_TextChanged);
            // 
            // editBox3
            // 
            this.editBox3.Label = "Opportunity";
            this.editBox3.Name = "editBox3";
            this.editBox3.Text = null;
            this.editBox3.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.EditBox3_TextChanged);
            // 
            // editBox4
            // 
            this.editBox4.Label = "Job Number";
            this.editBox4.Name = "editBox4";
            this.editBox4.Text = null;
            this.editBox4.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.EditBox4_TextChanged);
            // 
            // group3
            // 
            this.group3.Items.Add(this.button9);
            this.group3.Label = "Table Of Contents";
            this.group3.Name = "group3";
            // 
            // button9
            // 
            this.button9.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button9.Label = "Update TOC";
            this.button9.Name = "button9";
            this.button9.OfficeImageId = "CustomPageNumberGallery";
            this.button9.ShowImage = true;
            this.button9.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button9_Click);
            // 
            // group1
            // 
            this.group1.Items.Add(this.label1);
            this.group1.Items.Add(this.editBox1);
            this.group1.Items.Add(this.buttonGroup1);
            this.group1.Items.Add(this.separator1);
            this.group1.Items.Add(this.label2);
            this.group1.Items.Add(this.editBox5);
            this.group1.Items.Add(this.box1);
            this.group1.Items.Add(this.separator2);
            this.group1.Items.Add(this.label3);
            this.group1.Items.Add(this.editBox6);
            this.group1.Items.Add(this.buttonGroup2);
            this.group1.Items.Add(this.separator3);
            this.group1.Items.Add(this.label4);
            this.group1.Items.Add(this.editBox7);
            this.group1.Items.Add(this.buttonGroup3);
            this.group1.Label = "Auto Numbering";
            this.group1.Name = "group1";
            // 
            // label1
            // 
            this.label1.Label = "Cable Label Numbering";
            this.label1.Name = "label1";
            // 
            // editBox1
            // 
            this.editBox1.Label = "Label Number";
            this.editBox1.Name = "editBox1";
            this.editBox1.Text = null;
            this.editBox1.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.EditBox1_TextChanged);
            // 
            // buttonGroup1
            // 
            this.buttonGroup1.Items.Add(this.button5);
            this.buttonGroup1.Items.Add(this.button1);
            this.buttonGroup1.Name = "buttonGroup1";
            // 
            // button5
            // 
            this.button5.Label = "Reset";
            this.button5.Name = "button5";
            this.button5.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button5_Click);
            // 
            // button1
            // 
            this.button1.Label = "Go";
            this.button1.Name = "button1";
            this.button1.OfficeImageId = "DatabaseLinedTableManager";
            this.button1.ShowImage = true;
            this.button1.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button1_Click);
            // 
            // separator1
            // 
            this.separator1.Name = "separator1";
            // 
            // label2
            // 
            this.label2.Label = "Cable Pull # Numbering";
            this.label2.Name = "label2";
            // 
            // editBox5
            // 
            this.editBox5.Label = "\"#\" Number";
            this.editBox5.Name = "editBox5";
            this.editBox5.Text = null;
            // 
            // box1
            // 
            this.box1.Items.Add(this.button6);
            this.box1.Items.Add(this.button2);
            this.box1.Items.Add(this.checkBox1);
            this.box1.Name = "box1";
            // 
            // button6
            // 
            this.button6.Label = "Reset";
            this.button6.Name = "button6";
            this.button6.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button6_Click);
            // 
            // button2
            // 
            this.button2.Label = "Go";
            this.button2.Name = "button2";
            this.button2.OfficeImageId = "DatabaseModelingRefresh";
            this.button2.ShowImage = true;
            this.button2.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button2_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.Checked = true;
            this.checkBox1.Label = "All Pages";
            this.checkBox1.Name = "checkBox1";
            // 
            // separator2
            // 
            this.separator2.Name = "separator2";
            // 
            // label3
            // 
            this.label3.Label = "I/O Numbering";
            this.label3.Name = "label3";
            // 
            // editBox6
            // 
            this.editBox6.Label = "Port Number";
            this.editBox6.Name = "editBox6";
            this.editBox6.Text = null;
            this.editBox6.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.EditBox6_TextChanged);
            // 
            // buttonGroup2
            // 
            this.buttonGroup2.Items.Add(this.button7);
            this.buttonGroup2.Items.Add(this.button3);
            this.buttonGroup2.Name = "buttonGroup2";
            // 
            // button7
            // 
            this.button7.Label = "Reset";
            this.button7.Name = "button7";
            this.button7.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button7_Click);
            // 
            // button3
            // 
            this.button3.Label = "Go";
            this.button3.Name = "button3";
            this.button3.OfficeImageId = "DatabaseEncodeDecode";
            this.button3.ShowImage = true;
            this.button3.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button3_Click);
            // 
            // separator3
            // 
            this.separator3.Name = "separator3";
            // 
            // label4
            // 
            this.label4.Label = "Device Numbering";
            this.label4.Name = "label4";
            // 
            // editBox7
            // 
            this.editBox7.Label = "Device Number";
            this.editBox7.Name = "editBox7";
            this.editBox7.Text = null;
            this.editBox7.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.EditBox7_TextChanged);
            // 
            // buttonGroup3
            // 
            this.buttonGroup3.Items.Add(this.button8);
            this.buttonGroup3.Items.Add(this.button4);
            this.buttonGroup3.Name = "buttonGroup3";
            // 
            // button8
            // 
            this.button8.Label = "Reset";
            this.button8.Name = "button8";
            this.button8.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button8_Click);
            // 
            // button4
            // 
            this.button4.Label = "Go";
            this.button4.Name = "button4";
            this.button4.OfficeImageId = "DatabaseAnalyzeTable";
            this.button4.ShowImage = true;
            this.button4.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.Button4_Click);
            // 
            // group4
            // 
            this.group4.Items.Add(this.button10);
            this.group4.Items.Add(this.dropDown1);
            this.group4.Label = "Revision Log";
            this.group4.Name = "group4";
            // 
            // button10
            // 
            this.button10.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button10.Label = "New Revision Entry";
            this.button10.Name = "button10";
            this.button10.OfficeImageId = "AdpStoredProcedureQueryAppend";
            this.button10.ShowImage = true;
            this.button10.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button10_Click);
            // 
            // dropDown1
            // 
            ribbonDropDownItemImpl1.Label = "ECO";
            ribbonDropDownItemImpl2.Label = "ICO";
            this.dropDown1.Items.Add(ribbonDropDownItemImpl1);
            this.dropDown1.Items.Add(ribbonDropDownItemImpl2);
            this.dropDown1.Label = "Revision Type";
            this.dropDown1.Name = "dropDown1";
            // 
            // CTI_Utilties
            // 
            this.Name = "CTI_Utilties";
            this.RibbonType = "Microsoft.Visio.Drawing";
            this.Tabs.Add(this.tab1);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.CTI_Utilties_Load);
            this.tab1.ResumeLayout(false);
            this.tab1.PerformLayout();
            this.group2.ResumeLayout(false);
            this.group2.PerformLayout();
            this.group3.ResumeLayout(false);
            this.group3.PerformLayout();
            this.group1.ResumeLayout(false);
            this.group1.PerformLayout();
            this.buttonGroup1.ResumeLayout(false);
            this.buttonGroup1.PerformLayout();
            this.box1.ResumeLayout(false);
            this.box1.PerformLayout();
            this.buttonGroup2.ResumeLayout(false);
            this.buttonGroup2.PerformLayout();
            this.buttonGroup3.ResumeLayout(false);
            this.buttonGroup3.PerformLayout();
            this.group4.ResumeLayout(false);
            this.group4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab tab1;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group2;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group3;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group1;
        internal Microsoft.Office.Tools.Ribbon.RibbonLabel label1;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox editBox1;
        internal Microsoft.Office.Tools.Ribbon.RibbonButtonGroup buttonGroup1;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button1;
        internal Microsoft.Office.Tools.Ribbon.RibbonLabel label2;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox editBox2;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox editBox3;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox editBox4;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button9;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button5;
        internal Microsoft.Office.Tools.Ribbon.RibbonSeparator separator1;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox editBox5;
        internal Microsoft.Office.Tools.Ribbon.RibbonBox box1;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button6;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button2;
        internal Microsoft.Office.Tools.Ribbon.RibbonCheckBox checkBox1;
        internal Microsoft.Office.Tools.Ribbon.RibbonSeparator separator2;
        internal Microsoft.Office.Tools.Ribbon.RibbonLabel label3;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox editBox6;
        internal Microsoft.Office.Tools.Ribbon.RibbonButtonGroup buttonGroup2;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button7;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button3;
        internal Microsoft.Office.Tools.Ribbon.RibbonSeparator separator3;
        internal Microsoft.Office.Tools.Ribbon.RibbonLabel label4;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox editBox7;
        internal Microsoft.Office.Tools.Ribbon.RibbonButtonGroup buttonGroup3;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button8;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button4;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group4;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button10;
        internal Microsoft.Office.Tools.Ribbon.RibbonDropDown dropDown1;
    }

    partial class ThisRibbonCollection
    {
        internal CTI_Utilties CTI_Utilties
        {
            get { return this.GetRibbon<CTI_Utilties>(); }
        }
    }
}

﻿using Microsoft.Office.Tools.Ribbon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Office = Microsoft.Office.Core;
using Visio = Microsoft.Office.Interop.Visio;

namespace CTI_Utilities
{
    public partial class CTI_Utilties
    {
        private void CTI_Utilties_Load(object sender, RibbonUIEventArgs e)
        {
            this.button1.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(
                this.Button1_Click);
        }

        private void Button1_Click(object sender, RibbonControlEventArgs e)
        {
            int startingNum;
            if (this.editBox1.Text == "")
            {
                startingNum = 101;
            }
            else
            {
                startingNum = int.Parse(this.editBox1.Text);
            }
            AutoNumbering("Cable_Num", startingNum);
        }

        //Auto Numbering '#' Shape Data
        private void Button2_Click(object sender, RibbonControlEventArgs e)
        {
            int x, Count;
            string tempToString, tempFromString;
            Visio.Application visioApplication = Globals.ThisAddIn.Application.Application;
            Visio.Document document = visioApplication.ActiveDocument;
            Visio.Shape visShape;
            const string CUST_PROP_PREFIX = "Prop.";


            Visio.Pages visioPages = document.Pages;
            Visio.Page page = visioPages[1];

            var myPageCol = new List<Visio.Page>();
            var myShapeCol = new List<Visio.Shape>();

            if (this.editBox5.Text == "")
            {
                Count = 1;
            }
            else
            {
                Count = int.Parse(this.editBox5.Text);
            }

            foreach (Visio.Page PageToIndex in document.Pages)
            {
                if (checkBox1.Checked == true)
                {
                    myPageCol.Add(PageToIndex);
                }
                else
                {
                    myPageCol.Add(visioApplication.ActivePage);
                }
            }


            foreach (Visio.Page PageToIndex in myPageCol)
            {
                if (PageToIndex.Background == page.Background)
                {
                    int intShapeCt, intX;
                    intShapeCt = PageToIndex.Shapes.Count;
                    for (intX = 1; intX <= intShapeCt; intX++)
                    {
                        visShape = PageToIndex.Shapes[intX];
                        bool b = visShape.Name.Contains("Pulled Cable V3");
                        if (b)
                        {
                            myShapeCol.Add(visShape);
                        }
                    }
                }
                else
                {

                }
            }
            while (myShapeCol.Count > 0)
            {

                Visio.Cell tempPropertyCell, compareToCell, compareFromCell, compareHashtagCell;
                string compareToString, compareFromString;
                Visio.Shape tempPropertyShape = myShapeCol[0];

                // Get the Cell object. Note the addition of "Prop." to the
                // name given to the cell.
                tempPropertyCell = tempPropertyShape.get_CellsU(CUST_PROP_PREFIX + "Cable_To");
                tempToString = tempPropertyCell.Formula;
                tempPropertyCell = tempPropertyShape.get_CellsU(CUST_PROP_PREFIX + "Cable_From");
                tempFromString = tempPropertyCell.Formula;
                for (x = myShapeCol.Count - 1; x >= 0; x--)
                {
                    Visio.Shape comparePropertyShape = myShapeCol[x];
                    compareToCell = comparePropertyShape.get_CellsU(CUST_PROP_PREFIX + "Cable_To");
                    compareFromCell = comparePropertyShape.get_CellsU(CUST_PROP_PREFIX + "Cable_From");
                    compareHashtagCell = comparePropertyShape.get_CellsU(CUST_PROP_PREFIX + "Cable_HashTag");
                    compareToString = compareToCell.Formula;
                    compareFromString = compareFromCell.Formula;
                    if (compareToString == tempToString && compareFromString == tempFromString)
                    {
                        compareHashtagCell.FormulaU = Count.ToString();
                        myShapeCol.RemoveAt(x);
                    }
                }
                Count++;
            }
        }

        private void Button3_Click(object sender, RibbonControlEventArgs e)
        {
            int startingNum;
            if (this.editBox6.Text == "")
            {
                startingNum = 1;
            }
            else
            {
                startingNum = int.Parse(this.editBox6.Text);
            }
            AutoNumbering("IO_NUM", startingNum);
        }

        private void Button4_Click(object sender, RibbonControlEventArgs e)
        {
            int startingNum;
            if (this.editBox7.Text == "")
            {
                startingNum = 1;
            }
            else
            {
                startingNum = int.Parse(this.editBox7.Text);
            }
            AutoNumbering("DeviceNum", startingNum);
        }

        private void Button5_Click(object sender, RibbonControlEventArgs e)
        {
            this.editBox1.Text = "";
            return;
        }

        private void Button6_Click(object sender, RibbonControlEventArgs e)
        {
            editBox5.Text = "";
        }

        private void Button7_Click(object sender, RibbonControlEventArgs e)
        {
            editBox6.Text = "";
        }

        private void Button8_Click(object sender, RibbonControlEventArgs e)
        {
            editBox7.Text = "";
        }

        //TABLE OF CONTENTS UPDATE
        private void Button9_Click(object sender, RibbonControlEventArgs e)
        {
            Visio.Documents visioDocuments = Globals.ThisAddIn.Application.Documents;
            Visio.Document document = Globals.ThisAddIn.Application.ActiveDocument;
            Visio.Document stencil;
            Visio.Master masterInStencil;
            Visio.Shape shapesInMaster;
            Visio.Shape testShape;
            Visio.Shape visShape;
            Visio.Pages pages = document.Pages;
            Visio.Page page = pages[1];
            int intX2;
            int x_location = 5;
            double y_location = 17.0;


            for (intX2 = page.Shapes.Count; intX2 >= 1; intX2--)
            {
                visShape = page.Shapes[intX2];
                bool b = visShape.Name.Contains("TOC");
                if (b)
                {
                    visShape.Delete();
                }
            }

            try
            {
                stencil = visioDocuments["TitlePage Stencil.vssx"];
            }
            catch (System.Runtime.InteropServices.COMException)
            {

                // The stencil is not in the collection; open it as a 
                // docked stencil.
                stencil = visioDocuments.OpenEx("TitlePage Stencil.vssx",
                    (short)Microsoft.Office.Interop.Visio.
                    VisOpenSaveArgs.visOpenDocked);
            }

            // Get a master from the stencil by its universal name.
            foreach (Visio.Page eachPage in document.Pages)
            {
                if (eachPage.Background == page.Background)
                {
                    Visio.Page thisPage;
                    int intShapeCt, intX, x;
                    thisPage = eachPage;
                    intShapeCt = eachPage.Shapes.Count;
                    for (intX = 1; intX <= intShapeCt; intX++)
                    {
                        visShape = eachPage.Shapes[intX];
                        if (visShape.Name == "PageTitle")
                        {
                            Visio.Characters vsoCharacters, vsoCharacters1;
                            masterInStencil = stencil.Masters.get_ItemU("TOC Entry");
                            testShape = masterInStencil.Shapes[1];
                            testShape.Name = "TOC Entry";
                            vsoCharacters1 = visShape.Characters;
                            testShape = page.Drop(testShape, x_location, y_location);
                            for (x = 1; x <= 3; x++)
                            {
                                shapesInMaster = testShape.Shapes[x];
                                vsoCharacters = shapesInMaster.Characters;
                                if (x == 1)
                                {
                                    vsoCharacters.Text = visShape.Text;
                                }
                                else if (x == 2)
                                {
                                    vsoCharacters.Text = eachPage.Name;
                                }
                                else if (x == 3)
                                {
                                    vsoCharacters.Text = eachPage.Index.ToString();
                                }

                            }
                            y_location -= 0.5;
                        }
                    }
                }
            }
        }

        private void EditBox1_TextChanged(object sender, RibbonControlEventArgs e)
        {
            int startingNum;
            if (this.editBox1.Text == "")
            {
                startingNum = 101;
            }
            else
            {
                startingNum = int.Parse(this.editBox1.Text);
            }
            AutoNumbering("Cable_Num", startingNum);
        }

        private void EditBox2_TextChanged(object sender, RibbonControlEventArgs e)
        {
            AccountSet(editBox2.Text);
        }

        private void EditBox3_TextChanged(object sender, RibbonControlEventArgs e)
        {
            OpportunitySet(editBox3.Text);
        }

        private void EditBox4_TextChanged(object sender, RibbonControlEventArgs e)
        {
            JobNumSet(editBox4.Text);
        }

        private void EditBox6_TextChanged(object sender, RibbonControlEventArgs e)
        {
            int startingNum;
            if (this.editBox6.Text == "")
            {
                startingNum = 1;
            }
            else
            {
                startingNum = int.Parse(this.editBox6.Text);
            }
            AutoNumbering("IO_NUM", startingNum);
        }

        private void EditBox7_TextChanged(object sender, RibbonControlEventArgs e)
        {
            int startingNum;
            if (this.editBox7.Text == "")
            {
                startingNum = 1;
            }
            else
            {
                startingNum = int.Parse(this.editBox7.Text);
            }
            AutoNumbering("DeviceNum", startingNum);
        }

        public void AutoNumbering(string rowNameU, int startingIncrementNum)
        {
            int x;
            Visio.Application visioApplication = Globals.ThisAddIn.Application.Application;
            Visio.Window window = visioApplication.ActiveWindow;
            Visio.Selection theSelection;
            theSelection = window.Selection;

            Visio.Shape customPropertyShape;

            const string CUST_PROP_PREFIX = "Prop.";
            try
            {

                for (x = 1; x <= theSelection.Count; x++)
                {
                    string incrementedNumStr;
                    customPropertyShape = theSelection[x];

                    Visio.Cell customPropertyCell;

                    // Get the Cell object. Note the addition of "Prop." to the
                    // name given to the cell.
                    customPropertyCell = customPropertyShape.get_CellsU(CUST_PROP_PREFIX + rowNameU);
                    incrementedNumStr = startingIncrementNum.ToString();
                    customPropertyCell.FormulaU = incrementedNumStr;
                    startingIncrementNum++;
                }
                return;
            }
            catch (System.Runtime.InteropServices.COMException)
            {

            }
        }
        public void AccountSet(string strAccount)
        {
            Visio.Document document = Globals.ThisAddIn.Application.ActiveDocument;
            document.Company = strAccount;
        }
        public void OpportunitySet(string strOpportunity)
        {
            Visio.Document document = Globals.ThisAddIn.Application.ActiveDocument;
            document.Title = strOpportunity;
        }
        public void JobNumSet(string strJobNumber)
        {
            Visio.Document document = Globals.ThisAddIn.Application.ActiveDocument;
            document.Subject = strJobNumber;
        }

        private void button10_Click(object sender, RibbonControlEventArgs e)
        {
            Visio.Documents visioDocuments = Globals.ThisAddIn.Application.Documents;
            Visio.Document document = Globals.ThisAddIn.Application.ActiveDocument;
            Visio.Document stencil;
            Visio.Master masterInStencil;
            //Visio.Shape shapesInMaster;
            Visio.Shape testShape;
            Visio.Shape visShape;
            Visio.Pages pages = document.Pages;
            Visio.Page page = pages[1];

            int intX2;
            int x_location = 16;
            double y_location = 17.0;

            
            Visio.Characters vsoCharacters;
            try
            {
                stencil = visioDocuments["TitlePage Stencil.vssx"];
            }
            catch (System.Runtime.InteropServices.COMException)
            {

                // The stencil is not in the collection; open it as a 
                // docked stencil.
                stencil = visioDocuments.OpenEx("TitlePage Stencil.vssx",
                    (short)Microsoft.Office.Interop.Visio.
                    VisOpenSaveArgs.visOpenDocked);
            }

            for (intX2 = page.Shapes.Count; intX2 >= page.Shapes.Count; intX2--)
            {
                visShape = page.Shapes[intX2];

                if (visShape.Name.Contains("Revision"))
                {
                    short sectionIndex = 5;
                    bool returnValue = false;
                    //Visio.Section currentSection;
                    Visio.Cell currentCell;
                    Visio.Shape shapesInMaster;

                    //short rowCount = 1;
                    //short cellCount = 1;
                    string cellYValue;
                    double cellYInt;
                    double cellShapeRevNum;
                    string cellXValue, revDateString;
                    int revNumInt;
                    // Iterate through the Shape Transform section.
                    //sectionIndex = (short)Microsoft.Office.Interop.Visio.
                    //    VisSectionIndices.visSectionObject;
                    System.Diagnostics.Debug.WriteLine(
                        "\r\nSHAPE TRANSFORM SECTION");
                    //currentSection = visShape.get_Section(sectionIndex);
                    currentCell = visShape.get_CellsU("PinY");
                    cellYValue = currentCell.Formula;
                    cellYInt = currentCell.get_Result("in");
                    shapesInMaster = visShape.Shapes[3];
                    vsoCharacters = shapesInMaster.Characters;
                    revNumInt = int.Parse(vsoCharacters.Text);
                    //cellYInt = int.Parse(cellYValue);
                    shapesInMaster = visShape.Shapes[2];
                    vsoCharacters = shapesInMaster.Characters;
                    revDateString = vsoCharacters.Text;
                    vsoCharacters.Text = revDateString;
                    //
                    y_location = cellYInt - 0.5;
                    currentCell = visShape.get_CellsU("PinX");
                    cellXValue = currentCell.Formula;
                    System.Diagnostics.Debug.WriteLine(cellYInt);
                    System.Diagnostics.Debug.WriteLine(cellYValue.ToString());
                    System.Diagnostics.Debug.WriteLine(revDateString);
                    //returnValue = iterateSection(visShape, sectionIndex);


                    // Get a master from the stencil by its universal name.

                    //if (eachPage.Background == page.Background)
                    //{
                    //Visio.Page thisPage;
                    int intShapeCt, intX, x;

                    Visio.Characters vsoCharacters1;//vsoCharacters
                    masterInStencil = stencil.Masters.get_ItemU("Revision Entry");
                    testShape = masterInStencil.Shapes[1];
                    vsoCharacters1 = testShape.Characters;
                    testShape = page.Drop(testShape, x_location, y_location);
                    cellShapeRevNum = revNumInt + 1.00;
                    shapesInMaster = testShape.Shapes[3];
                    vsoCharacters = shapesInMaster.Characters;
                    //revNumInt = int.Parse(vsoCharacters.Text);
                    vsoCharacters.Text = cellShapeRevNum.ToString();
                    shapesInMaster = testShape.Shapes[4];
                    vsoCharacters = shapesInMaster.Characters;
                    //revNumInt = int.Parse(vsoCharacters.Text);
                    vsoCharacters.Text = dropDown1.SelectedItem.ToString();

                    if (page == document.Pages[document.Pages.Count])
                    {
                        break;
                    }
                    else
                    {
                        foreach (Visio.Shape revisionShape in document.Pages[pages.Count].Shapes)
                        {
                            if (revisionShape.Name.Contains("revisionShape"))
                            {
                                masterInStencil = stencil.Masters.get_ItemU("Revision Entry");
                                testShape = masterInStencil.Shapes[1];
                                vsoCharacters1 = testShape.Characters;
                                //testShape = document.Pages[pages.Count].Drop(testShape, 100, 100);
                                cellShapeRevNum = revNumInt + 1.00;
                                shapesInMaster = revisionShape.Shapes[1];
                                vsoCharacters = shapesInMaster.Characters;
                                //revNumInt = int.Parse(vsoCharacters.Text);
                                vsoCharacters.Text = cellShapeRevNum.ToString();
                                shapesInMaster = revisionShape.Shapes[2];
                                vsoCharacters = shapesInMaster.Characters;
                                //revNumInt = int.Parse(vsoCharacters.Text);
                                vsoCharacters.Text = dropDown1.SelectedItem.ToString();
                                //
                                shapesInMaster = revisionShape.Shapes[4];
                                vsoCharacters = shapesInMaster.Characters;
                                //revNumInt = int.Parse(vsoCharacters.Text);
                                vsoCharacters.Text = revDateString;
                            }
                        }
                    }

                }
                
            }
        



                    //thisPage = eachPage;
                    //intShapeCt = pages[1].Shapes.Count;
                    //for (intX = 1; intX <= intShapeCt; intX++)
                    //{
                    //    visShape = eachShape;
                    //    if (visShape.Name.Contains("Revision Entry"))
                    //    {
                    //        Visio.Characters vsoCharacters, vsoCharacters1;
                    //        masterInStencil = stencil.Masters.get_ItemU("Revision Entry");
                    //        testShape = masterInStencil.Shapes[1];
                    //        testShape.Name = "TOC Entry";
                    //        vsoCharacters1 = visShape.Characters;
                    //        //testShape = page.Drop(testShape, x_location, y_location);
                    //        for (x = 1; x <= 3; x++)
                    //        {
                    //            shapesInMaster = testShape.Shapes[x];
                    //            vsoCharacters = shapesInMaster.Characters;
                    //            vsoCharacters.Text = visShape.Text;

                    //        }
                    //        y_location -= 0.5;
                    //    }
                    //}
                    //}
        }
        private static bool iterateSection(
           Microsoft.Office.Interop.Visio.Shape targetShape,
           short sectionIndex)
        {

            Microsoft.Office.Interop.Visio.Section currentSection;
            Microsoft.Office.Interop.Visio.Cell currentCell;
            short rowCount;
            short cellCount;
            string cellFormula;
            bool returnValue = false;

            try
            {

                // Get the row count for this section.
                currentSection = targetShape.get_Section(sectionIndex);
                rowCount = targetShape.get_RowCount(sectionIndex);

                // Iterate through each row in this section.
                for (short rowIndex = 0; rowIndex < rowCount; rowIndex++)
                {

                    cellCount = targetShape.get_RowsCellCount(sectionIndex,
                        rowIndex);
                    if (cellCount == 0)
                    {

                        cellCount = targetShape.get_RowsCellCount(sectionIndex,
                            ++rowIndex);
                    }

                    // Get each of the cells in this section.
                    for (short cellIndex = 0; cellIndex < cellCount;
                        cellIndex++)
                    {

                        currentCell = currentSection[rowIndex][cellIndex];
                        cellFormula = currentCell.FormulaU;

                        // Replace empty formula strings with "No Formula"
                        if (0 == cellFormula.Length)
                        {

                            cellFormula = "No Formula";
                        }

                        // Output the cell to the debug window
                        System.Diagnostics.Debug.WriteLine(currentCell.Name +
                            " - Formula: " + cellFormula +
                            ", Value: " +
                            currentCell.get_ResultStr(currentCell.Units));
                    }
                }

                returnValue = true;
            }
            catch (Exception err)
            {
                System.Diagnostics.Debug.WriteLine(err.Message);
                throw;
            }

            return returnValue;
        }

       
    }

    
}
